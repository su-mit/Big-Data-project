package dmlqueries;
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.ZooKeeperConnectionException;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;

public class Get {
public static void main(String[] args) throws MasterNotRunningException, ZooKeeperConnectionException, IOException {
	
	Configuration conf = HBaseConfiguration.create();  
	HBaseAdmin admin = new HBaseAdmin(conf); 
	HTable hTable = new HTable(conf,"student"); 
	Get get = new Get(Bytes.toBytes("1"));
	hTable.get(get);
	admin.close();
	
}
}
