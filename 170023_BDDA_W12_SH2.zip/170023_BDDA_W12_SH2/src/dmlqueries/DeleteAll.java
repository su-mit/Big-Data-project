package dmlqueries;
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.ZooKeeperConnectionException;
import org.apache.hadoop.hbase.client.Delete;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;

public class DeleteAll {
public static void main(String[] args) throws MasterNotRunningException, ZooKeeperConnectionException, IOException {
	
	Configuration config = HBaseConfiguration.create();  
	HBaseAdmin admin = new HBaseAdmin(config); 
	HTable hTable = new HTable(config,"student"); 
	TableName[] list_Of_Tables = admin.listTableNames("s.*");
	String[] str_array = new String[list_Of_Tables.length];
	for (int i = 0; i<list_Of_Tables.length;i++) {
		str_array[i] = list_Of_Tables[i].getNameAsString();
	}
	for (String x:str_array) {
		Delete del = new Delete(Bytes.toBytes(x));
		hTable.delete(del);
	}
		admin.close();
		
}

}
