package actions;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Font;
import ui.UserInterface.TabNames;

public class DeleteRecord {
	/**********************************************************************************************

	Class Attributes
	
	**********************************************************************************************/
	
	//---------------------------------------------------------------------------------------------
	// These attributes enable us to hide the details of the tab height and the height and width of
	// of the window decorations for the code that implements this user interface
	private static int xOffset = 0;
	private static int yOffset = 0;
	static java.sql.Statement stat;

	private static Label theTitle;
	
	private static Button btnSubmit = new Button("Delete");
	
	private static Label lblRollNo = new Label("Roll No.");
	private static TextField tfRollNo = new TextField();
	
 
	/**********
	 * This constructor establishes the base ListItem and then initializes the Life Cycle specific
	 * attributes for the application.
	 * 
	 * @param g		The Group link is used to establish the list of GUI elements for this tab
	 * @param x		The x offset for the GUI elements to fit into the decorative borders
	 * @param y		The y offset
	 * @param t		The enumeration that helps select the right strings for labels, etc.
	 */
	public DeleteRecord(Group reportControls, int x, int y, TabNames report) {
		nextMethod(reportControls, x, y, report);
		}
	
	
	public static void nextMethod(Group g, int x, int y, TabNames t) {
		xOffset = x;
		yOffset = y;
		theTitle = new Label("Report");
		setupLabelUI(theTitle, "Arial", 30, 100, Pos.BASELINE_LEFT, 10 + xOffset, 20 + yOffset);
		
		
		setupLabelUI(lblRollNo, "Arial", 24, 100, Pos.BASELINE_LEFT, 10 + xOffset, 100 + yOffset);
		setupTextUI(tfRollNo, "Arial", 20, 320, Pos.BASELINE_LEFT, 150 + xOffset, 100 + yOffset);
		
		setupButtonUI(btnSubmit, "Arial", 20, 50, Pos.BASELINE_LEFT, 520 + xOffset, 140 + yOffset);
		
		btnSubmit.setOnAction((event)->{
			
			getTheResults();			
		});
	
		
		g.getChildren().addAll(theTitle,lblRollNo, tfRollNo, btnSubmit);
	}
	
	
	private static void getTheResults() {
				
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
   			Connection con = null;
		
			// Setting-up the connection
			try {
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root","Naven@30");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    	
			try {
				stat = con.createStatement();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 	// Creating statement 
		    
			String statment = "Delete from info where roll_no = " + tfRollNo.getText() +"";
						
			try {
				stat.executeUpdate(statment);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
		
	}
	


	/**********
	 * Private local method to initialize the standard fields for a JavaFX Label object
	 * 
	 * @param l		The Label object to be initialized
	 * @param ff	The font face for the label's text
	 * @param f		The font size for the label's text
	 * @param w		The minimum width for the Label
	 * @param p		The alignment for the text within the specified width
	 * @param x		The x-axis location for the Label
	 * @param y		The y-axis location for the Label
	 */
	private static void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y){
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}
	/**********
	 * Private local method to initialize the standard fields for a text field
	 * 
	 * @param t		The TextField object to be initialized
	 * @param ff	The font face for the label's text
	 * @param f		The font size for the label's text
	 * @param w		The minimum width for the TextField
	 * @param p		The alignment for the text within the specified width
	 * @param x		The x-axis location for the TextField
	 * @param y		The y-axis location for the TextField
	 * @param e		A flag that specific if the TextField is editable
	 */
	private static void setupTextUI(TextField t, String ff, double f, double w, Pos p, double x, double y){
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);		
	}

	/**********
	 * Private local method to initialize the standard fields for a button
	 * 
	 * @param b		The Button to be initialized
	 * @param ff	The font face for the label's text
	 * @param f		The font size for the label's text
	 * @param w		The minimum width for the TextArea
	 * @param p		The alignment for the text within the specified width
	 * @param x		The x-axis location for the TextField
	 * @param y		The y-axis location for the TextField
	 */
	private static void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y){
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);		
	}
	

}
