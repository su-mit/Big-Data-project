package actions;

import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.text.Font;
import ui.UserInterface.TabNames;

public class ShowRecords {
	/**********************************************************************************************

	Class Attributes
	
	**********************************************************************************************/
	
	//---------------------------------------------------------------------------------------------
	// These attributes enable us to hide the details of the tab height and the height and width of
	// of the window decorations for the code that implements this user interface
	private static int xOffset = 0;
	private static int yOffset = 0;
	static java.sql.Statement stat;

	private static Label theTitle;
	
	private static Button btnSubmit = new Button("Show report");
		
	
	
	/**********
	 * This constructor establishes the base ListItem and then initializes the Life Cycle specific
	 * attributes for the application.
	 * 
	 * @param g		The Group link is used to establish the list of GUI elements for this tab
	 * @param x		The x offset for the GUI elements to fit into the decorative borders
	 * @param y		The y offset
	 * @param t		The enumeration that helps select the right strings for labels, etc.
	 */
	public ShowRecords(Group rgControls, int x, int y, TabNames reportGeneration) {
		nextMethod(rgControls, x, y, reportGeneration);
		
	
	

	}
	
	
	public static void nextMethod(Group g, int x, int y, TabNames t) {
		xOffset = x;
		yOffset = y;
		theTitle = new Label("Report Generation");
		setupLabelUI(theTitle, "Arial", 30, 100, Pos.BASELINE_LEFT, 10 + xOffset, 20 + yOffset);
		
		setupButtonUI(btnSubmit, "Arial", 20, 50, Pos.BASELINE_LEFT, 250 + xOffset, 340 + yOffset);
		
		btnSubmit.setOnAction((event) -> {
			
			getTheResults();
			
		});
		
		g.getChildren().addAll(theTitle, btnSubmit);
	}
	/**********
	 * Private local method to initialize the standard fields for a JavaFX Label object
	 * 
	 * @param l		The Label object to be initialized
	 * @param ff	The font face for the label's text
	 * @param f		The font size for the label's text
	 * @param w		The minimum width for the Label
	 * @param p		The alignment for the text within the specified width
	 * @param x		The x-axis location for the Label
	 * @param y		The y-axis location for the Label
	 */
	private static void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y){
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}


	/**********
	 * Private local method to initialize the standard fields for a button
	 * 
	 * @param b		The Button to be initialized
	 * @param ff	The font face for the label's text
	 * @param f		The font size for the label's text
	 * @param w		The minimum width for the TextArea
	 * @param p		The alignment for the text within the specified width
	 * @param x		The x-axis location for the TextField
	 * @param y		The y-axis location for the TextField
	 */
	private static void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y){
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);		
	}
	
	private static void getTheResults() {
				
		Document studentReport = new Document();
		try {
			PdfWriter.getInstance(studentReport, new FileOutputStream("StudentRecordAll.pdf"));
		
		studentReport.open();
		PdfPTable table = new PdfPTable(8);
		table.addCell("Roll Number");
		table.addCell("Reg No"); 
		table.addCell("Name"); 
		table.addCell("Father's Name"); 
		table.addCell("Mpther's Name"); 
		table.addCell("Course"); 
		table.addCell("Semester"); 
		table.addCell("Year"); 
		
			Class.forName("com.mysql.cj.jdbc.Driver");
		
   			Connection con = null;
		
			// Setting-up the connection
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root","Naven@30");
		    	
			stat = con.createStatement(); 	// Creating statement 
		    
			String statment = "Select * from info ";
			
			ResultSet set = stat.executeQuery(statment);
			
			while(set.next()) {
			
								
				table.addCell(String.valueOf(set.getString(1))); 
				table.addCell(String.valueOf(set.getString(2)));
				table.addCell(String.valueOf(set.getString(3)));
				table.addCell(String.valueOf(set.getString(4)));
				table.addCell(String.valueOf(set.getString(5)));
				table.addCell(String.valueOf(set.getString(6)));
				table.addCell(String.valueOf(set.getString(7)));
				table.addCell(String.valueOf(set.getString(8)));
				
			}
		studentReport.add(table);
			
		studentReport.close();
		Desktop.getDesktop().open(new File("StudentRecordAll.pdf"));
		}
		 catch (DocumentException | IOException | SQLException | ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}


	

}
