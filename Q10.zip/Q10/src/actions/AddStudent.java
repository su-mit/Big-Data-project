package actions;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import ui.UserInterface.TabNames;

public class AddStudent extends Application{

	/**********************************************************************************************

	Class Attributes
	
	**********************************************************************************************/
	
	//---------------------------------------------------------------------------------------------
	// These attributes enable us to hide the details of the tab height and the height and width of
	// of the window decorations for the code that implements this user interface
	private static int xOffset = 0;
	private static int yOffset = 0;

	private static Label theTitle;
	
	private static Button btnSubmit = new Button("Submit");
	
	private static Label lblSem = new Label("Semister");
	static String semister[] = { "sem 1", "sem 2", "sem 3", "sem 4", "sem 5" };
	private static ComboBox<String> semCombo = new ComboBox<String>(FXCollections.observableArrayList(semister));
	
	
	private static Label lblYear = new Label("Year");
	static String year[] = { "2016-17", "2017-18", "2018-19", "2019-20", "2020-21" };
	private static ComboBox<String> yearCombo = new ComboBox<String>(FXCollections.observableArrayList(year));
	
	
	private static TextField tfName = new TextField();
	private static Label lblName = new Label("Name");
	
	private static TextField tfRg = new TextField();
	private static Label lblRg = new Label("Rg No.");
	
	private static TextField tfRNo = new TextField();
	private static Label lblRNo = new Label("Roll No.");
	
	private static TextField tfFN = new TextField();
	private static Label lblFN = new Label("F Name");
	
	private static TextField tfMN = new TextField();
	private static Label lblMN = new Label("M Name");
	
	private static TextField tfC = new TextField();
	private static Label lblC = new Label("Course");
	
	
	/**********
	 * This constructor establishes the base ListItem and then initializes the Life Cycle specific
	 * attributes for the application.
	 * 
	 * @param g		The Group link is used to establish the list of GUI elements for this tab
	 * @param x		The x offset for the GUI elements to fit into the decorative borders
	 * @param y		The y offset
	 * @param t		The enumeration that helps select the right strings for labels, etc.
	 */
	public AddStudent(Group studentMasterControls, int x, int y, TabNames studentMaster) {
		nextMethod(studentMasterControls, x, y, studentMaster);
	

	}
	
	
	public static void nextMethod(Group g, int x, int y, TabNames t) {
		xOffset = x;
		yOffset = y;
		theTitle = new Label("Add new student");
		setupLabelUI(theTitle, "Arial", 30, 100, Pos.BASELINE_LEFT, 10 + xOffset, 20 + yOffset);
		
		
		setupLabelUI(lblSem, "Arial", 24, 100, Pos.BASELINE_LEFT, 10 + xOffset, 100 + yOffset);
		setupComboBoxUI(semCombo, 100, 150 + xOffset, 100 + yOffset);
		
		setupLabelUI(lblYear, "Arial", 24, 100, Pos.BASELINE_LEFT, 400 + xOffset, 100 + yOffset);
		setupComboBoxUI(yearCombo, 100, 500 + xOffset, 100 + yOffset);
		
		setupLabelUI(lblName, "Arial", 24, 100, Pos.BASELINE_LEFT, 10 + xOffset, 150 + yOffset);
		setupTextUI(tfName, "Arial", 20, 320, Pos.BASELINE_LEFT, 150 + xOffset, 150 + yOffset);
		
		setupLabelUI(lblRg, "Arial", 24, 100, Pos.BASELINE_LEFT, 10 + xOffset, 200 + yOffset);
		setupTextUI(tfRg, "Arial", 20, 320, Pos.BASELINE_LEFT, 150 + xOffset, 200 + yOffset);
		
		setupLabelUI(lblRNo, "Arial", 24, 100, Pos.BASELINE_LEFT, 10 + xOffset, 250 + yOffset);
		setupTextUI(tfRNo, "Arial", 20, 320, Pos.BASELINE_LEFT, 150 + xOffset, 250 + yOffset);
		
		setupLabelUI(lblFN, "Arial", 24, 100, Pos.BASELINE_LEFT, 10 + xOffset, 300 + yOffset);
		setupTextUI(tfFN, "Arial", 20, 320, Pos.BASELINE_LEFT, 150 + xOffset, 300 + yOffset);
		
		setupLabelUI(lblMN, "Arial", 24, 100, Pos.BASELINE_LEFT, 10 + xOffset, 350 + yOffset);
		setupTextUI(tfMN, "Arial", 20, 320, Pos.BASELINE_LEFT, 150 + xOffset, 350 + yOffset);
		
		setupLabelUI(lblC, "Arial", 24, 100, Pos.BASELINE_LEFT, 10 + xOffset, 400 + yOffset);
		setupTextUI(tfC, "Arial", 20, 320, Pos.BASELINE_LEFT, 150 + xOffset, 400 + yOffset);
		
		
		setupButtonUI(btnSubmit, "Arial", 20, 50, Pos.BASELINE_LEFT, 250 + xOffset, 460 + yOffset);
				
		
		btnSubmit.setOnAction((event)->{
				
			addStudent();
						
		});
		
		
		g.getChildren().addAll(theTitle,lblSem, semCombo, lblYear, yearCombo, lblName, tfName,  btnSubmit, 
				tfRg, lblRg, tfRNo, lblRNo, tfFN, lblFN, tfMN, lblMN, tfC, lblC);
		
		}
	
	
	private static void addStudent() {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		
		
			Connection con = null;
	
		// Setting-up the connection
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root","Naven@30");
	    	
		Statement stat;
		
		stat = con.createStatement(); 	// Creating statement 
		
		String str = "Insert into info values ('" + tfRNo.getText() + "' ,'" + tfRNo.getText() + "', '" + tfName.getText() + "' ,'"
				+ tfFN.getText() + "', '" + tfMN.getText() + "' ,'" + tfC.getText() + "' ,'" +semCombo.getSelectionModel().getSelectedItem() 
				+ "', '" + yearCombo.getSelectionModel().getSelectedItem() + "')";
		
		stat.executeUpdate(str);
	    
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	/**********
	 * Private local method to initialize the standard fields for a JavaFX Label object
	 * 
	 * @param l		The Label object to be initialized
	 * @param ff	The font face for the label's text
	 * @param f		The font size for the label's text
	 * @param w		The minimum width for the Label
	 * @param p		The alignment for the text within the specified width
	 * @param x		The x-axis location for the Label
	 * @param y		The y-axis location for the Label
	 */
	private static void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y){
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}
	/**********
	 * Private local method to initialize the standard fields for a text field
	 * 
	 * @param t		The TextField object to be initialized
	 * @param ff	The font face for the label's text
	 * @param f		The font size for the label's text
	 * @param w		The minimum width for the TextField
	 * @param p		The alignment for the text within the specified width
	 * @param x		The x-axis location for the TextField
	 * @param y		The y-axis location for the TextField
	 */
	private static void setupTextUI(TextField t, String ff, double f, double w, Pos p, double x, double y){
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);		
	}

	/**********
	 * Private local method to initialize the standard fields for a button
	 * 
	 * @param b		The Button to be initialized
	 * @param ff	The font face for the label's text
	 * @param f		The font size for the label's text
	 * @param w		The minimum width for the TextArea
	 * @param p		The alignment for the text within the specified width
	 * @param x		The x-axis location for the TextField
	 * @param y		The y-axis location for the TextField
	 */
	private static void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y){
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);		
	}
	
	/**********
	 * Private local method to initialize the standard fields for a button
	 * @param w		The minimum width for the comboBox
	 * @param x		The x-axis location for the TextField
	 * @param y		The y-axis location for the TextField
	 */
	private static void setupComboBoxUI(ComboBox<String> cb,double w, double x, double y) {
		cb.setMinWidth(w);
		cb.setLayoutX(x);
		cb.setLayoutY(y);
	}


	@Override
	public void start(Stage arg0) throws Exception {
		// TODO Auto-generated method stub
				
	}

	
	
	
}
